from cybervpn import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/momok/statushariini"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu|.gas|.mulai|.memek|.go|.crot)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("Ssh Menu", "ssh")],
                    [Button.inline("Vmess Menu", "vmess-member"),
                     Button.inline("Vless Menu", "vless-member")],
                    [Button.inline("Trojan Menu", "trojan-member"),
                     Button.inline("Socks Menu", "shadowsocks-member")],
                    [Button.inline("Noobzv Vpn", "noobzvpn-member")],
                    [Button.url("✨whatsapp✨", "https://wa.me/6285955333616"),
                     Button.inline("💵Topup Manual💵", f"topup")]
                ]

                member_msg = f"""
**=========================**
**☠️☠️LUNATIC TUNNELING☠️☠️**
**=========================**
**» SSH WEBSOCKET :** `{get_ssh_status()}`
**» X-RAY LIBEV   :** `{get_xray_status()}`
**» UDP CUSTOM    :** `{get_udp_status()}`
**━━━━━━━━━━━━━━━━**
**» 🇲🇨SCRIPTS VER :** `v4.7.7`
**» 🇲🇨YOUR ID NAME:** `{user_id}`
**» 🇲🇨REMAIN MONEY: ** `RP.{saldo_aji}`
**━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                    [Button.inline("[ SSHOVPN UDP ]", "ssh")],
                    [Button.inline("[ VMESS LIBEV ]", "vmess"),
                     Button.inline("[ VLESS LIBEV ]", "vless")],
                    [Button.inline("[ TRJAN LIBEV ]", "trojan"),
                     Button.inline("[ SDWSK LIBEV ]", "shadowsocks")],
                    [Button.inline("[ NOOBZ LIBEV ]", "noobzvpns"),
                     Button.inline("[ ADD MEMBERR ]", "registrasi-member"),
                     Button.inline("[ DEL MEMBERS ]", "delete-member")],
                    [Button.inline("[ LIST MEMBER ]", "show-user")],
                    [Button.inline("💰 ADD MONEY 💰 ", "addsaldo")],
                    [Button.inline("👙CHECKING VPS👙", "info"),
                     Button.inline("👙FEATURES SET👙", "setting")],
                    [Button.url("📩Whatsapp📩", "https://wa.me/6285955333616"),
                     Button.url("📤BuyScript📤", "https://wa.me/6285955333616")]
                ]

                admin_msg = f"""
**=========================**
**☠️☠️LUNATIC TUNNELING☠️☠️**
**=========================**
**» SSH WEBSOCKET :** `{get_ssh_status()}`
**» X-RAY LIBEV   :** `{get_xray_status()}`
**» UDP CUSTOM    :** `{get_udp_status()}`
**=========================**
**» 🇲🇨SCRIPTS VER :** `v4.7.7`
**» 🇲🇨YOUR ID NAME:** `{user_id}`
**» 🇲🇨REMAIN MONEY: ** `RP.{saldo_aji}`
**=========================**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'```Anda belum terdaftar, silahkan registrasi```',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

